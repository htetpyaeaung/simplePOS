package test;

public class MyTableModel {

}
