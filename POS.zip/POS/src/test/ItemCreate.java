package test;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;

public class ItemCreate extends JFrame{
	JPanel n = new JPanel();
	JButton btn_save = new JButton("Save");
    JButton btn_close = new JButton("Close");
    JComboBox cboType = new JComboBox();
    
    JButton btn1 = new JButton("btn1");
    JButton btn2 = new JButton("btn2");
    
	JLabel label = new JLabel ("Type");
	int typeID = 0;
	DB obj = new DB();
	
	public ItemCreate() {
		setSize(300,300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		GridBagConstraints gbc = new GridBagConstraints();  
        setTitle("Item");  
        GridBagLayout layout = new GridBagLayout();  
        setLayout(layout);  
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 0;  
        
        JLabel jl = new JLabel("Type");
        add(jl,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 0;  
        
        gbc.gridwidth = 1;
        add(cboType,gbc);  
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 1;  
        JLabel jlb = new JLabel("Name");
        add(jlb,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 1;  
        
        JTextField txtField = new JTextField();
        gbc.gridwidth = 1;
        add(txtField,gbc);  
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 2;  
        JLabel jlc = new JLabel("Price");
        add(jlc,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 2;  
        
        JTextField txtPrice = new JTextField();
        gbc.gridwidth = 1;
        add(txtPrice,gbc);  
        
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.ipady = 20;  
        gbc.gridx = 0;  
        gbc.gridy = 3;  
        
        add(btn_save, gbc);  
        gbc.gridx = 1;  
		gbc.gridy = 3;  
		
		btn_close.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
			
		});
		add(btn_close,gbc);
		
		cboType.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(cboType.getSelectedIndex()>0) {
					String sql = "select * from type where name = '"+ cboType.getSelectedItem()+"'";
					ResultSet rs = obj.selectData(sql);
					
					
					try {
						rs.next();
						typeID = rs.getInt(1);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
				else {
					typeID=0;
				}
			}
			
		});
		
		showType();
		
		btn_save.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(cboType.getSelectedIndex()>0) {
					if(!txtField.getText().equals("")) {
						if(!txtPrice.getText().equals("")) {
							boolean numeric = true;
					        numeric = txtPrice.getText().matches("-?\\d+(\\.\\d+)?");
					        if(numeric) {
								String sql = "select * from item where name = '"+ txtField.getText()+"'" ;
								ResultSet rs = obj.selectData(sql);
								try {
									rs.last();
									int size = rs.getRow();
									if(size> 0) {
										JOptionPane.showMessageDialog(null, "Duplicate Data");
									}
									else {
										sql = "insert into item(name,type_id,price) values('"+txtField.getText()+ "',"
												+typeID+","+txtPrice.getText()+")";
										obj.saveData(sql);
										txtField.setText("");
										txtPrice.setText("");
										cboType.setSelectedIndex(0);
										typeID=0;
										JOptionPane.showMessageDialog(null, "Save Successfully");
									}
								} catch (SQLException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
					        }
					        else {
					        	JOptionPane.showMessageDialog(null, "Enter Number");
					        }
						}
						else {
							JOptionPane.showMessageDialog(null, "Enter Price");
						}
					}
					else {
						JOptionPane.showMessageDialog(null, "Enter Name");
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "Choose ID");
				}
			}
			
		});
		
		
		
		
		setPreferredSize(getSize());  
		setVisible(true);
	}
	
	
	public void showType() {
		String sql = "select * from type";
		ResultSet rs = obj.selectData(sql);
		
		cboType.removeAllItems();
		cboType.addItem("--Select--");
		try {
			while(rs.next()) 
				cboType.addItem(rs.getString(2));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) {
		ItemCreate cre = new ItemCreate();

	}

}
