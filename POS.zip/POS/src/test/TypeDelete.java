package test;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;

public class TypeDelete extends JFrame {

	JLabel lbl = new JLabel("ID");
	JComboBox cbo_id = new JComboBox();
	JLabel lbl1 = new JLabel("Type");
	JTextField txtType = new JTextField();
	JButton btn_delete = new JButton("Delete");
	JButton btn_close = new JButton("Close");
	DB obj = new DB();
	
	public TypeDelete() {
		setSize(300,300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Delete");
		setLocationRelativeTo(null);
		
		GridBagConstraints gbc = new GridBagConstraints();  
        GridBagLayout layout = new GridBagLayout();  
        setLayout(layout);  
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 0;  
        JLabel jli = new JLabel("ID");
        add(jli,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 0;  
        
        
        gbc.gridwidth = 1;
        add(cbo_id,gbc);  
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 1;  
        JLabel jl = new JLabel("Type");
        add(jl,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 1;  
        
        JTextField txtField = new JTextField();
        gbc.gridwidth = 1;
        add(txtField,gbc);  
        
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.ipady = 20;  
        gbc.gridx = 0;  
        gbc.gridy = 2;  
        
        add(btn_delete, gbc);  
        gbc.gridx = 1;  
		gbc.gridy = 2;  
		
		btn_close.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
			
		});
		add(btn_close,gbc);
		showData();
		
		cbo_id.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(cbo_id.getSelectedIndex()>0) {
					String sql = "select * from type where id = "+ cbo_id.getSelectedItem();
					ResultSet rs = obj.selectData(sql);
					
					try {
						rs.next();
						txtField.setText(rs.getString(2));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				else {
					txtField.setText("");
				}
				
			}
			
		});
		
		btn_delete.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				if(cbo_id.getSelectedIndex()>0) {
					if(JOptionPane.showConfirmDialog(null, "Sure Delete?", "Delete", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) { 
						String sql = "delete from type where id = " + cbo_id.getSelectedItem();
						obj.saveData(sql);
						JOptionPane.showMessageDialog(null, "Delete Successfully");
						showData();
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "Choose IDDDD");
				}
			}
			
		});
		
		
		setVisible(true);
	}
	
	public void showData() {
		String sql = "select * from type";
		ResultSet rs = obj.selectData(sql);
//		cbo_id.removei
		cbo_id.removeAllItems();
		
		cbo_id.addItem("--Select--");
		
		try {
			while(rs.next())
			cbo_id.addItem(rs.getInt(1));
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	public static void main(String[] args) {
		TypeDelete delete = new TypeDelete();

	}

}
