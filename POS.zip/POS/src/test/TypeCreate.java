package test;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import java.sql.*;

public class TypeCreate extends JFrame{
	JPanel n = new JPanel();
	 JButton btn_save = new JButton("Save");
     JButton btn_close = new JButton("Close");
	
	public TypeCreate() {
        GridBagConstraints gbc = new GridBagConstraints();  
        setTitle("Type");  
        GridBagLayout layout = new GridBagLayout();  
        setLayout(layout);  
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 0;  
        JLabel jl = new JLabel("Type");
        add(jl,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 0;  
        
        JTextField txtField = new JTextField();
        gbc.gridwidth = 1;
        add(txtField,gbc);  
        
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.ipady = 20;  
        gbc.gridx = 0;  
        gbc.gridy = 1;  
        
        add(btn_save, gbc);  
        gbc.gridx = 1;  
		gbc.gridy = 1;  
		
		
		btn_close.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
			
		});
		
		btn_save.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(txtField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please Enter type");
					txtField.requestFocus();
				}
				else {
					DB obj = new DB();
					String sql = "select * from type where name = '"+ txtField.getText()+"'";
					ResultSet rs =  obj.selectData(sql);
				    try {
				    	rs.last();
						int size = rs.getRow();
						if(size >0) {
							JOptionPane.showMessageDialog(null, "Duplicate Data");
						}
						else {
							sql = "insert into type(name) values('" + txtField.getText() + "')";
							obj.saveData(sql);
							JOptionPane.showMessageDialog(null, "Save Successfully");
							txtField.setText("");
							txtField.requestFocus();
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
			}
			
		});
		
		add(btn_close,gbc);
		
		
        setSize(300, 300);  
        setPreferredSize(getSize());  
        setLocationRelativeTo(null);
        setVisible(true);  
        setDefaultCloseOperation(EXIT_ON_CLOSE);  
	}
	
	
	
	public static void main(String[] args) {
		TypeCreate p = new TypeCreate();
		
	}

}

