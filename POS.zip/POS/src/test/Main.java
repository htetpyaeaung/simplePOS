package test;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Main extends JFrame{

	JPanel p1 = new JPanel();
	JMenuBar mnu = new JMenuBar();
	JMenu mnu_file = new JMenu("File");
	JMenu mnu_entry = new JMenu("Entry");
	JMenu mnu_update = new JMenu("Update");
	JMenu mnu_delete = new JMenu("Delete");
	JMenu mnu_list = new JMenu("List");
	
	JMenuItem mnu_file_exit = new JMenuItem("Exit");
	JMenuItem mnu_file_sale = new JMenuItem("Sale");
	JMenuItem mnu_entry_type = new JMenuItem("Type");
	JMenuItem mnu_entry_item = new JMenuItem("Item");
	JMenuItem mnu_update_type = new JMenuItem("Type");
	JMenuItem mnu_update_item = new JMenuItem("Item");
	JMenuItem mnu_delete_type = new JMenuItem("Type");
	JMenuItem mnu_delete_item = new JMenuItem("Item");
	JMenuItem mnu_list_type = new JMenuItem("Type");
	JMenuItem mnu_list_item = new JMenuItem("Item");
	JMenuItem mnu_list_sale = new JMenuItem("Sale");
	
	
	public Main() {
		setSize(500, 500);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("KFC SALE POS SYSTEM");
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());
//		setResizable(false);
		
		mnu.add(mnu_file);
		mnu.add(mnu_entry);
		mnu.add(mnu_update);
		mnu.add(mnu_delete);
		mnu.add(mnu_list);
		
		mnu_file.add(mnu_file_exit);
		mnu_file.add(mnu_file_sale);
		
		mnu_entry.add(mnu_entry_type);
		mnu_entry.add(mnu_entry_item);
		
		mnu_update.add(mnu_update_type);
		mnu_update.add(mnu_update_item);
		
		mnu_delete.add(mnu_delete_type);
		mnu_delete.add(mnu_delete_item);
		
		mnu_list.add(mnu_list_type);
		mnu_list.add(mnu_list_item);
		mnu_list.add(mnu_list_sale);
		
		Image img = Toolkit.getDefaultToolkit().getImage("KFC.jpg");
		setContentPane(new JPanel() {
			public void paintComponent(Graphics g) {
	            super.paintComponent(g);
	            g.drawImage(img, 0, 0, getWidth(),getHeight(),this);
	         }
		});
		
		mnu_entry_type.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				TypeCreate tc = new TypeCreate();
				
			}
			
		});

		mnu_update_type.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				TypeUpdate tu = new TypeUpdate();
				
			}
			
		});
		
		mnu_delete_type.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				TypeDelete td = new TypeDelete();
				
			}
			
		});
		
		mnu_list_type.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				TypeList tl = new TypeList();
				
			}
			
		});
		
		mnu_entry_item.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ItemCreate tc = new ItemCreate();
				
			}
			
		});

		mnu_update_item.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ItemUpdate tu = new ItemUpdate();
				
			}
			
		});
		
		mnu_delete_item.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ItemDelete td = new ItemDelete();
				
			}
			
		});
		
		mnu_list_item.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ItemList tl = new ItemList();
				
			}
			
		});
		
		mnu_list_sale.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				SaleList sl = new SaleList();
				
			}
			
		});
		
		mnu_file_sale.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Sale s = new Sale();
				
			}
			
		});
		
		add(mnu, BorderLayout.NORTH);
		
		setVisible(true);
	}
	
	
	
	
	public static void main(String[] args) {
		Main mNu = new Main();

	}

}
