package test;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;

public class ItemUpdate extends JFrame {

	JPanel n = new JPanel();
	JButton btn_save = new JButton("Save");
    JButton btn_close = new JButton("Close");
    JComboBox cboType = new JComboBox();
    JComboBox cboItemID = new JComboBox();
    DB obj = new DB();
    int typeID = 0;
	
	
	
	public ItemUpdate() {
		setSize(300,300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		GridBagConstraints gbc = new GridBagConstraints();  
        setTitle("Item");  
        GridBagLayout layout = new GridBagLayout();  
        setLayout(layout);  
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 0;  
        
        JLabel jl1 = new JLabel("ID");
        add(jl1,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 0;  
        
        gbc.gridwidth = 1;
        add(cboItemID,gbc); 
        
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 1;  
        
        JLabel jl = new JLabel("Type");
        add(jl,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 1;  
        
        gbc.gridwidth = 1;
        add(cboType,gbc);  
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 2;  
        JLabel jlb = new JLabel("Name");
        add(jlb,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 2;  
        
        JTextField txtField = new JTextField();
        gbc.gridwidth = 1;
        add(txtField,gbc);  
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 3;  
        JLabel jlc = new JLabel("Price");
        add(jlc,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 3;  
        
        JTextField txtPrice = new JTextField();
        gbc.gridwidth = 1;
        add(txtPrice,gbc);  
        
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.ipady = 20;  
        gbc.gridx = 0;  
        gbc.gridy = 4;  
        
        add(btn_save, gbc);  
        gbc.gridx = 1;  
		gbc.gridy = 4;  
		
		btn_close.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
			
		});
		add(btn_close,gbc);
		
		showItem();
		showType();
		
		cboItemID.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(cboItemID.getSelectedIndex()>0) {
					String sql = "select * from item inner join type on type_id = type.id where item.id = "+cboItemID.getSelectedItem();
					ResultSet rs = obj.selectData(sql);
					try {
						rs.next();
						txtField.setText(rs.getString(2));
						txtPrice.setText(rs.getString(4));
						cboType.setSelectedItem(rs.getString(6));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
				else {
					txtField.setText("");
					txtPrice.setText("");
					cboType.setSelectedIndex(0);
				}
			}
			
		});
		
		cboType.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(cboType.getSelectedIndex()>0) {
					String sql = "select * from type where name = '" + cboType.getSelectedItem()+"'";
					ResultSet rs = obj.selectData(sql);
					try {
						rs.next();
						typeID = rs.getInt(1);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
				else {
					typeID = 0;
				}
			}
			
		});
		
		btn_save.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
					if(cboItemID.getSelectedIndex()<=0) {
						JOptionPane.showMessageDialog(null, "Choose ID");
					}
					else if(cboType.getSelectedIndex()<=0) {
						JOptionPane.showMessageDialog(null, "Choose Type");
					}
					else if(txtField.getText().equals("")) {
						JOptionPane.showMessageDialog(null, "Enter Name");
					}
					else if (txtPrice.getText().equals("")) {
						JOptionPane.showMessageDialog(null, "Enter Price");
					}
					else {
						boolean numeric = true;
						numeric = txtPrice.getText().matches("-?\\d+(\\.\\d+)?");
						if(!numeric) {
							JOptionPane.showMessageDialog(null, "Enter numbers");
						}
						else {
							String sql = "update item set name = '"+ txtField.getText() 
							+"',type_id = "+typeID+ ",price="+txtPrice.getText()+" where id = "+ cboItemID.getSelectedItem();
							obj.saveData(sql);
							JOptionPane.showMessageDialog(null, "Save Successfully");
							txtField.setText("");
							txtPrice.setText("");
							cboType.setSelectedIndex(0);
							cboItemID.setSelectedIndex(0);
						}
					
					
					}
			}
			
		});
		
		
		
		setPreferredSize(getSize());  
		setVisible(true);
	}
	
	public void showItem() {
		String sql = "select * from item inner join type on type_id = type.id order by item.id";
		ResultSet rs = obj.selectData(sql);
		cboItemID.removeAllItems();
		cboItemID.addItem("--Select--");
		try {
			while (rs.next()) {
				cboItemID.addItem(rs.getInt(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void showType() {
		String sql = "select * from type";
		ResultSet rs = obj.selectData(sql);
		cboType.removeAllItems();
		cboType.addItem("--Select--");
		try {
			while(rs.next()) {
				cboType.addItem(rs.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		ItemUpdate update = new ItemUpdate();

	}

}
