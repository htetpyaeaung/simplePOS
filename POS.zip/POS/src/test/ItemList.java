package test;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class ItemList extends JFrame {

	JLabel lblName = new JLabel("Name");
	JTextField txtName = new JTextField(5);
	JComboBox cbo_type = new JComboBox();
	JButton btn_search = new JButton("Search");
	JButton btn_showAll = new JButton("Show All");
	JPanel p2 = new JPanel();
	DB obj = new DB();
	
	DefaultTableModel model = new DefaultTableModel();
	
	public ItemList() {
		setSize(500, 300);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Item Lists");
		setLayout(new FlowLayout());
		setResizable(false);
		
		
		JPanel outerPanel = new JPanel(new BorderLayout());
	    JPanel topPanel = new JPanel(new BorderLayout());
	    
	    JLabel label = new JLabel("Name:");
	    JTable table = new JTable(model);

	    
	    add(label);
	    add(cbo_type);
	    add(btn_search);
	    add(btn_showAll);
	    add(table);
	    model.addColumn("ID");
	    model.addColumn("Name");
	    model.addColumn("Type");
	    model.addColumn("Price");
	   
	    outerPanel.add(table,BorderLayout.CENTER);
	    
	    
	    add(outerPanel);
	    
	    getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);
	    
		showData("select * from item inner join type on type_id = type.id");
		showType();
		
		btn_search.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(cbo_type.getSelectedIndex()<=0) {
					JOptionPane.showMessageDialog(null, "Enter Type");
				}
				else {
					String sql = "select * from item inner join type on type_id = type.id where type.name = '"
							+ cbo_type.getSelectedItem()+"'";
					showData(sql);
				}
			}
			
		});
		
		btn_showAll.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				showData("select * from item inner join type on type_id = type.id");
				cbo_type.setSelectedIndex(0);
			}
			
		});
		
		
		setVisible(true);
	}
	
	public void showData(String sql) {
		if (model.getRowCount() > 0) {
            for (int j = model.getRowCount() - 1; j > -1; j--) {
                model.removeRow(j);
            }
        }
		ResultSet rs = obj.selectData(sql);
		try {
			while(rs.next()) {
				Object[] itemD = {rs.getInt(1), rs.getString(2),rs.getString(6),rs.getInt(4)};
				model.addRow(itemD);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void showType() {
		String sql = "select * from type";
		ResultSet rs = obj.selectData(sql);
		cbo_type.addItem("--Select--");
		try {
			while(rs.next()) {
				cbo_type.addItem(rs.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	public static void main(String[] args) {
		ItemList iList = new ItemList();

	}

}
