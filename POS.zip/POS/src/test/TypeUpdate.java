package test;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;


public class TypeUpdate extends JFrame{
	JButton btn_update = new JButton("Update");
	JButton btn_close = new JButton("Close");
	JComboBox cbo_id = new JComboBox();
	DB obj = new DB();
	
	public TypeUpdate() {
		GridBagConstraints gbc = new GridBagConstraints();  
        setTitle("Update Type");  
        GridBagLayout layout = new GridBagLayout();  
        setLayout(layout);  
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 0;  
        JLabel jli = new JLabel("ID");
        add(jli,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 0;  
        
        
        gbc.gridwidth = 1;
        add(cbo_id,gbc);  
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 1;  
        JLabel jl = new JLabel("Type");
        add(jl,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 1;  
        
        JTextField txtField = new JTextField();
        gbc.gridwidth = 1;
        add(txtField,gbc);  
        
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.ipady = 20;  
        gbc.gridx = 0;  
        gbc.gridy = 2;  
        
        add(btn_update, gbc);  
        gbc.gridx = 1;  
		gbc.gridy = 2;  
		
		
		btn_close.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
			
		});
		add(btn_close,gbc);
		
		
		String sql = "select * from type";
		ResultSet rs = obj.selectData(sql);
		
		try {
			cbo_id.addItem("--Select--");
			while(rs.next()) {
				cbo_id.addItem(rs.getString(1));
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		cbo_id.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(cbo_id.getSelectedIndex()>0) {
					String sql = "select * from type where id = "+ cbo_id.getSelectedItem();
					ResultSet rs = obj.selectData(sql);
					try {
						rs.next();
						txtField.setText(rs.getString(2));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				
				}
				else {
					txtField.setText("");
				}
			}
			
		});
		
		btn_update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(cbo_id.getSelectedIndex()==0) {
					JOptionPane.showMessageDialog(null, "Choose ID");
				}
				else if(txtField.getText().equals("")){
					JOptionPane.showMessageDialog(null, "Enter Type :-P");
				}
				else {
				String sql = "Select * from type where name = '"+ txtField.getText()+"'";
				ResultSet rs = obj.selectData(sql);
				
				
				try {
					rs.next();
					int id = rs.getInt(1);
					rs.last();
					int size = rs.getRow();
					if(size>0 && id != Integer.parseInt(cbo_id.getSelectedItem().toString())) {
						JOptionPane.showMessageDialog(null, "Duplicate Data");
					}
					else {
						 sql = "update type set name = '"+ txtField.getText() + 
									"' where id ="+ cbo_id.getSelectedItem();
							obj.saveData(sql);
							JOptionPane.showMessageDialog(null, "Successfully Update");
							txtField.setText("");
							cbo_id.setSelectedIndex(0);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				}
			}
			
		});
		
		
		
        setSize(300, 300);  
        setPreferredSize(getSize());  
        setLocationRelativeTo(null);
        setVisible(true);  
        setDefaultCloseOperation(EXIT_ON_CLOSE); 
	}
	
	public static void main(String[] args) {
		TypeUpdate update = new TypeUpdate();
		
	}
}
