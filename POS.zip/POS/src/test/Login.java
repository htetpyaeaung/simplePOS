package test;

import java.awt.CardLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;

public class Login extends JFrame implements Runnable{
	JPanel n = new JPanel();
	JButton btn_login = new JButton("Login");
    JButton btn_close = new JButton("Close");
    JComboBox cboType = new JComboBox();
    static Login l;
    
    JPanel p1 = new JPanel();
    JPanel p2 = new JPanel();
    
    JButton btn1 = new JButton("btn1");
    JButton btn2 = new JButton("btn2");
    
    JProgressBar pb = new JProgressBar();
    
    
	JLabel label = new JLabel ("Type");
	JTextField txtField = new JTextField();
	int typeID = 0;
	DB obj = new DB();
	
	public Login() {
		setSize(300,300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		GridBagConstraints gbc = new GridBagConstraints();  
        setTitle("Item");  
        GridBagLayout layout = new GridBagLayout();  
        setLayout(new CardLayout());  
        p1.setLayout(layout);
        
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 0;  
        
        JLabel jl = new JLabel("Name");
        p1.add(jl,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 0;  
        
        gbc.gridwidth = 1;
        p1.add(txtField,gbc);  
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 1;  
        JLabel jlc = new JLabel("Password");
        p1.add(jlc,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 1;  
        
        JPasswordField txtPass = new JPasswordField();
        gbc.gridwidth = 1;
        p1.add(txtPass,gbc);  
        
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.ipady = 20;  
        gbc.gridx = 0;  
        gbc.gridy = 2;  
        
        p1.add(btn_login, gbc);  
        gbc.gridx = 1;  
		gbc.gridy = 2;  
		
		btn_close.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
			
		});
		p1.add(btn_close,gbc);
		
		add(p1);
		add(p2);
		p1.setVisible(false);
		
		p2.add(pb);
		
		GridBagLayout playout = new GridBagLayout();
	    GridBagConstraints cons = new GridBagConstraints();

	//set the constraints properties

	playout.addLayoutComponent(pb, cons);
	p2.setLayout(playout);
		
		
		btn_login.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(txtField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Enter Name");
				}
				else if(txtPass.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Enter Password");
				}
				else {
					String sql ="select * from user where name = '"+ txtField.getText()+"' AND password = '"
							+ txtPass.getText()+"'";
					ResultSet rs = obj.selectData(sql);
					try {
						if(rs.next()) {
//							Main m = new Main();
//							dispose();
							p1.setVisible(false);
							p2.setVisible(true);
							
							Thread tr = new Thread(l);
							tr.start();
							
						}
						else {
							JOptionPane.showMessageDialog(null, "Invalid User and password");
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
				
			}
			
		});
			
		
		
		
		setPreferredSize(getSize());  
		setVisible(true);
	}
	
	
	
	public static void main(String[] args) {
		l = new Login();

	}



	@Override
	public void run() {
		for(int i=0;i<=100;i++) {
			
			try {
				pb.setValue(i);
				Thread.sleep(100);
				if(i==100) {
					Main m = new Main();
					dispose();
				}
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

}


