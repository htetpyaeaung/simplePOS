package test;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;

public class ItemDelete extends JFrame {

	JPanel n = new JPanel();
	JButton btn_delete = new JButton("Delete");
    JButton btn_close = new JButton("Close");
    JTextField lblType = new JTextField();
    JComboBox cboItemID = new JComboBox();
    DB obj = new DB();
    int typeID = 0;
	
	
	
	public ItemDelete() {
		setSize(300,300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		GridBagConstraints gbc = new GridBagConstraints();  
        setTitle("Item");  
        GridBagLayout layout = new GridBagLayout();  
        setLayout(layout);  
        lblType.setEditable(false);
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 0;  
        
        JLabel jl1 = new JLabel("ID");
        add(jl1,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 0;  
        
        gbc.gridwidth = 1;
        add(cboItemID,gbc); 
        
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 1;  
        
        JLabel jl = new JLabel("Type");
        add(jl,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 1;  
        
        gbc.gridwidth = 1;
        add(lblType,gbc);  
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 2;  
        JLabel jlb = new JLabel("Name");
        add(jlb,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 2;  
        
        JTextField txtField = new JTextField();
        gbc.gridwidth = 1;
        add(txtField,gbc);  
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;  
        gbc.gridy = 3;  
        JLabel jlc = new JLabel("Price");
        add(jlc,gbc);  
        
        
        gbc.gridx = 1;  
        gbc.gridy = 3;  
        
        JTextField txtPrice = new JTextField();
        gbc.gridwidth = 1;
        add(txtPrice,gbc);  
        
        
        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.ipady = 20;  
        gbc.gridx = 0;  
        gbc.gridy = 4;  
        
        add(btn_delete, gbc);  
        gbc.gridx = 1;  
		gbc.gridy = 4;  
		
		btn_close.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
			
		});
		add(btn_close,gbc);
		
		showItem();
		
		cboItemID.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(cboItemID.getSelectedIndex()>0) {
					String sql = "select * from item inner join type on type_id = type.id where item.id = "+cboItemID.getSelectedItem();
					ResultSet rs = obj.selectData(sql);
					try {
						rs.next();
						txtField.setText(rs.getString(2));
						txtPrice.setText(rs.getString(4));
						lblType.setText(rs.getString(6));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
				else {
					txtField.setText("");
					txtPrice.setText("");
					lblType.setText("");;
				}
			}
			
		});
		
		
		
		btn_delete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
					if(cboItemID.getSelectedIndex()<=0) {
						JOptionPane.showMessageDialog(null, "Choose ID");
					}
					else {
						if(JOptionPane.showConfirmDialog(null, "Delete Confirm","Delete Confirm",JOptionPane.YES_NO_OPTION)==(JOptionPane.YES_OPTION)) {
							String sql = "delete from item where id = "+ cboItemID.getSelectedItem();
							obj.saveData(sql);
							JOptionPane.showMessageDialog(null, "Delete Successfully");
							showItem();
						}
					}
			}		
			
		});
		
		
		
		setPreferredSize(getSize());  
		setVisible(true);
	}
	
	public void showItem() {
		String sql = "select * from item inner join type on type_id = type.id order by item.id";
		ResultSet rs = obj.selectData(sql);
		cboItemID.removeAllItems();
		cboItemID.addItem("--Select--");
		try {
			while (rs.next()) {
				cboItemID.addItem(rs.getInt(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) {
		ItemDelete delete = new ItemDelete();

	}

}
