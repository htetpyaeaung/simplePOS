package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class DB {
	
	public Connection connect() {
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://192.168.64.2:3306/kfc","hoho","moko");  
			//here sonoo is database name, root is username and password  
			return con;
			}catch(Exception e){
				System.out.println(e);
				return null;
				} 
		
	}
	
	public void saveData(String sql) {
		try{  
			Connection con = connect();
			Statement stmt=con.createStatement();  
			int i = stmt.executeUpdate(sql);  
			if(i <=0)  {
				JOptionPane.showMessageDialog(null, "Error in save data");
			}
			con.close();  
			}catch(Exception e){ System.out.println(e);} 
	}

	public ResultSet selectData(String sql) {
		try{  
			Connection con = connect();
			Statement stmt=con.createStatement();  
			ResultSet rs=stmt.executeQuery(sql);    

			return rs;
			}catch(Exception e){ 
				System.out.println(e);
				return null;
				} 
	}
	
//	public static void main(String[] args) {
//		String sql = "select * from type";
//		DB obj = new DB();
//		ResultSet rs = obj.selectData(sql);
//		
//		try {
//			while(rs.next())  
//				System.out.println(rs.getInt(1)+"  "+rs.getString(2));
//			
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}  
//			}

	}

