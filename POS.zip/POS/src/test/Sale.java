package test;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;    

public class Sale extends JFrame{

	JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JButton btn_remove=new JButton("Remove");  
    JButton btn_add=new JButton("Add");  
    JLabel lbl = new JLabel("Type");
    JLabel lbl1 = new JLabel("Item");
    JLabel lbl2 = new JLabel("Qty");
    JComboBox cbo_type = new JComboBox();
    JComboBox cbo_item = new JComboBox();
    JTextField txt_qty = new JTextField(10);
    
    JLabel lbl4 = new JLabel("Total");
    JTextField txt_total = new JTextField(20);
    JButton btn_save=new JButton("Save");  
    DB obj = new DB();
    
    int typeID =0;
    int itemID = 0;
    int price = 0;
    int total = 0;
	
    
	DefaultTableModel model = new DefaultTableModel();
    
	public Sale() {
		setSize(700,300);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Sale");
		setLayout(new BorderLayout());
		p1.setLayout(new FlowLayout());
		

//		p1.setLayout(new GridLayout(3,2,1,1));
		p1.add(lbl);
		p1.add(cbo_type);
		p1.add(lbl1);
		p1.add(cbo_item);
		p1.add(lbl2);
		p1.add(txt_qty);
		p1.add(btn_add);
		p1.add(btn_remove);
		
		
		model.addColumn("Item ID");
		model.addColumn("Name");
		model.addColumn("Qty");
		model.addColumn("Price");
		
		
		JTable table = new JTable(model);
		p2.add(table);
		 JScrollPane pane = new JScrollPane(table);
		 
		p3.setLayout(new FlowLayout());
		
		p3.add(lbl4);
		p3.add(txt_total);
		
		p3.add(btn_save);
		
		
		add(p1,BorderLayout.NORTH);
		add(pane,BorderLayout.CENTER);
		add(p3,BorderLayout.SOUTH);
		
		showType();
		
		cbo_item.addItem("--Select--");
		
		cbo_type.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(cbo_type.getSelectedIndex()<=0) {
					cbo_item.removeAllItems();
					cbo_item.addItem("--Select--");
					txt_qty.setText("");
				}
				else {
					String sql = "select * from type where name = '"+ cbo_type.getSelectedItem()+"'";
					ResultSet rs = obj.selectData(sql);
					try {
						rs.next();
						typeID = rs.getInt(1);
						sql = "select * from item where type_id = "+ typeID;
						showItem(sql);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
			}
			
		});
		
		btn_add.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(cbo_type.getSelectedIndex()<=0) {
					JOptionPane.showMessageDialog(null, "Choose Type");
				}
				else if(cbo_item.getSelectedIndex()<=0) {
					JOptionPane.showMessageDialog(null, "Choose Item");
				}
				else if(txt_qty.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Enter qty");
				}
				else {
					boolean numeric = true;
					numeric = txt_qty.getText().matches("-?\\d+(\\.\\d+)?");
					if(!numeric) {
						JOptionPane.showMessageDialog(null, "Enter numbers");
					}
					else {
						boolean add = true;
						for(int i =0 ;i<model.getRowCount(); i++) {
							if(Integer.parseInt(model.getValueAt(i, 0).toString())== itemID) {
								int oldQty = Integer.parseInt(model.getValueAt(i, 2).toString());
								oldQty += Integer.parseInt(txt_qty.getText());
								model.setValueAt(new Integer(oldQty), i, 2);
								add = false;
								total += (Integer.parseInt(txt_qty.getText())*price);
								txt_total.setText(String.valueOf(total));
								cbo_type.setSelectedIndex(0);
								cbo_item.setSelectedIndex(0);
								txt_qty.setText("");
							}
						}
						if(add) {
							Object[] saleD = {itemID, cbo_item.getSelectedItem(),txt_qty.getText(),price};
							model.addRow(saleD);
							total += (Integer.parseInt(txt_qty.getText())*price);
							txt_total.setText(String.valueOf(total));
							cbo_type.setSelectedIndex(0);
							cbo_item.setSelectedIndex(0);
							txt_qty.setText("");
						}
					}
				}
			}
			
		});
		
		btn_remove.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(model.getRowCount()<=0) {
					JOptionPane.showMessageDialog(null, "No Records");
				}
				else {
					int index = 0;
					total =0;
					index = table.getSelectedRow();
					model.removeRow(index);
					for(int i=0; i<model.getRowCount();i++) {
						total += Integer.parseInt(model.getValueAt(i, 2).toString()) * Integer.parseInt(model.getValueAt(i, 3).toString());
						
					}
					txt_total.setText(String.valueOf(total));
				}
			}
			
		});
		
		btn_save.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(model.getRowCount()<=0) {
					JOptionPane.showMessageDialog(null, "No Records");
				}
				else {
					DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
					LocalDateTime now = LocalDateTime.now();  
					String date = dtf.format(now);  
					int sale_id = 0;
					
					String sql = "insert into sale(date, total) values('"+ date +"',"+ total+")";
					obj.saveData(sql);
					
					
					sql = "select max(id) from sale";
					ResultSet rs = obj.selectData(sql);
					
					try {
						rs.next();
						sale_id = rs.getInt(1);
						
					} catch (SQLException e1) {
	
						e1.printStackTrace();
					}
					
					for(int i=0; i<model.getRowCount();i++) {
						sql = "insert into sale_detail(sale_id, item_id, qty, price) values("+ sale_id
								+","+Integer.parseInt(model.getValueAt(i, 0).toString())+","
								+Integer.parseInt(model.getValueAt(i, 2).toString())+","
								+Integer.parseInt(model.getValueAt(i, 3).toString())+")";
						obj.saveData(sql);
					}
					
					JOptionPane.showMessageDialog(null, "Save Successfully");
					if (model.getRowCount() > 0) {
			            for (int j = model.getRowCount() - 1; j > -1; j--) {
			                model.removeRow(j);
			            }
			        }
					txt_total.setText("");
					total = 0;
				}
			}
			
		});
		
		cbo_item.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(cbo_item.getSelectedIndex()<=0) {
					itemID = 0;
					price = 0;
				}
				else {
					String sql = "select * from item where name = '"+ cbo_item.getSelectedItem()+"'";
					ResultSet rs = obj.selectData(sql);
					try {
						rs.next();
						itemID = rs.getInt(1);
						price = rs.getInt(4);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
			
		});
		
		setVisible(true);
	}
	
	public void showType() {
		cbo_type.removeAllItems();
		cbo_type.addItem("--Select--");
		String sql = "select * from type";
		ResultSet rs = obj.selectData(sql);
		try {
			while(rs.next()) {
				cbo_type.addItem(rs.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void showItem(String sql) {
		cbo_item.removeAllItems();
		cbo_item.addItem("--Select--");
		ResultSet rs = obj.selectData(sql);
		try {
			while(rs.next()) {
				cbo_item.addItem(rs.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	public static void main(String[] args) {
		Sale nSale = new Sale();

	}

}
