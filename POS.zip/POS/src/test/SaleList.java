package test;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class SaleList extends JFrame {

	JLabel lblName = new JLabel("Name");
	 JComboBox text = new JComboBox();
	JButton btn_search = new JButton("Search");
	JButton btn_showAll = new JButton("Show All");
	JPanel p2 = new JPanel();
	
	DefaultTableModel model = new DefaultTableModel();
	DB obj = new DB();
	
	public SaleList() {
		setSize(500, 300);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Type Lists");
		setLayout(new FlowLayout());
		setResizable(false);
		
		model.addColumn("Sale ID");
		model.addColumn("Date");
		model.addColumn("Name");
		model.addColumn("Price");
		model.addColumn("Qty");
		
		
//		JPanel outerPanel = new JPanel(new BorderLayout());
//	    JPanel topPanel = new JPanel(new FlowLayout());
	    
	    JLabel label = new JLabel("Date:");
	    JTable table = new JTable(model) {
	    	private static final long serialVersionUID = 1L;

	        public boolean isCellEditable(int row, int column) {                
	                return false;               
	        };
	    };
	    

	    
	    
	    add(label);
	    add(text);
	    add(btn_search);
	    add(btn_showAll);
	    add(table);
	    
	    getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);

	   
	    String sql = "SELECT * FROM `sale_detail` INNER JOIN `sale` on sale_id = sale.id INNER JOIN `item` on item_id = item.id";
		showData(sql);
	    
		
		text.addItem("--Select--");
		sql = "select distinct date from sale";
		ResultSet rs = obj.selectData(sql);
		try {
			while(rs.next()) {
				text.addItem(rs.getString(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    btn_search.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(text.getSelectedIndex()<=0) {
					JOptionPane.showMessageDialog(null, "Choose Date");
				}
				else {
					String sql = "SELECT * FROM `sale_detail` INNER JOIN `sale` on sale_id = sale.id INNER JOIN `item` on item_id = item.id where date = '"
							+text.getSelectedItem()+"'";
					showData(sql);
				}
				
			}
	    	
	    });
	    
	    btn_showAll.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String sql = "SELECT * FROM `sale_detail` INNER JOIN `sale` on sale_id = sale.id INNER JOIN `item` on item_id = item.id";
				showData(sql);
				text.setSelectedIndex(0);
			}
	    	
	    });
	    
	    
//	    topPanel.add(label);
//	    topPanel.add(text);
//	    topPanel.add(btn_search);
//	    topPanel.add(btn_showAll);
//	    outerPanel.add(topPanel, BorderLayout.NORTH);
//	    model.addColumn("Column1");
	   
//	    outerPanel.add(table,BorderLayout.CENTER);
//	    
//	    
//	    add(outerPanel);
		
	    
		
		
		setVisible(true);
	}
	
	public void showData(String sql) {
		DB obj = new DB();
		
		ResultSet rs = obj.selectData(sql);
		if (model.getRowCount() > 0) {
            for (int j = model.getRowCount() - 1; j > -1; j--) {
                model.removeRow(j);
            }
        }
		try {
			while(rs.next()) {
				Object[] data = {rs.getInt(2),rs.getString(7), rs.getString(10),rs.getInt(5),rs.getInt(4)};
				model.addRow(data);
				
			}
			if(model.getRowCount()== 0) {
				JOptionPane.showMessageDialog(null, "No Results");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	
	public static void main(String[] args) {
		SaleList sList = new SaleList();
		

	}

}
